import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
const Body = () => {
    return (_jsxs("main", { children: [_jsxs("section", { className: "hero", children: [_jsx("h2", { children: "Welcome to Our Real Estate Platform" }), _jsx("p", { children: "Find your dream property today." }), _jsx("button", { children: "Browse Listings" })] }), _jsx("section", { className: "featured-properties", children: _jsx("h3", { children: "Featured Listings" }) })] }));
};
export default Body;
