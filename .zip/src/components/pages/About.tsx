
const About = () => {
    return (
        <div>
            <h1>About Us</h1>
            <p>We are a leading real estate agency providing top-notch services.</p>
        </div>
    );
};

export default About;