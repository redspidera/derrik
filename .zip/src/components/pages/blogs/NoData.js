import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
const NoData = () => {
    return (_jsxs("div", { className: "no-listings-container blog-bo", children: [_jsx("h2", { children: "No Blogs Match Your Keyword" }), _jsx("img", { src: "/img/residential.png", alt: "" }), _jsx("p", { children: "Try resetting your filters to see more listings." })] }));
};
export default NoData;
