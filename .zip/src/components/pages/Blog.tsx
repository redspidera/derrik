
const Blog = () => {
    return (
        <div>
            <h1>Our Blog</h1>
            <p>Read the latest news and articles from the real estate industry.</p>
        </div>
    );
};
export default Blog;