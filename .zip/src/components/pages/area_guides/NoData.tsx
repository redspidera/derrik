 
const NoData  = () => {

  return (
    <div className="no-listings-container blog-bo"  >
      <h2  >No Community Match Your Keyword</h2>
          <img src="/img/residential.png" alt="" />
      <p  >Try resetting your filters to see more listings.</p>
   
    </div>
  );
};

export default NoData;
