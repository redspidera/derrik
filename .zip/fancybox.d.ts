declare module '@fancyapps/ui' {
    export = Fancybox;
    const Fancybox: any;  // This will bypass TypeScript errors for now
}