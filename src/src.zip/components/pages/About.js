import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
const About = () => {
    return (_jsxs("div", { children: [_jsx("h1", { children: "About Us" }), _jsx("p", { children: "We are a leading real estate agency providing top-notch services." })] }));
};
export default About;
