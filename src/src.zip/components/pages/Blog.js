import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
const Blog = () => {
    return (_jsxs("div", { children: [_jsx("h1", { children: "Our Blog" }), _jsx("p", { children: "Read the latest news and articles from the real estate industry." })] }));
};
export default Blog;
